import { Geolocation } from '@ionic-native/geolocation';
import { Component, ViewChild, OnInit } from '@angular/core';
import { NavController,IonicPage,NavParams } from 'ionic-angular';
import { } from '@types/googlemaps';
import { WebIntent } from '@ionic-native/web-intent';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {
  @ViewChild('gmap') gmapElement: any;
  map: google.maps.Map;
  miPosicion: google.maps.LatLng;
  miMarcador: google.maps.Marker;
  activado: Boolean;
  nombre;
  celular;
  correo;
  contrasena;
  codigo;

  constructor(public navCtrl: NavController, private webIntent: WebIntent, private geolocation: Geolocation, navParams:NavParams) {
    this.nombre=navParams.get('nombre');
    this.celular=navParams.get('celular');
    this.correo=navParams.get('correo');
    this.contrasena=navParams.get('contrasena');
    this.codigo=navParams.get('codigo');
  }

  irCuenta(){
    this.navCtrl.push("CuentaPage",
    {nombre:this.nombre,
      celular:this.celular,
      correo:this.correo,
      contrasena:this.contrasena,
      codigo:this.codigo
    });
  }

  ngOnInit() {
    this.startGoogleMap();
  }

  startGoogleMap() {
    const mapProp = {
        center: new google.maps.LatLng(-0.224710, -78.516763),
        zoom: 12,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);
    this.iniciarMarcadores();
  }

  iniciarMarcadores() {
    this.miMarcador = new google.maps.Marker({
      position: new google.maps.LatLng(0,0),
      map: this.map,
      draggable: false
    });
    this.obtenerMiPosicion();
  }

  obtenerMiPosicion() {
    this.geolocation.getCurrentPosition().then((resp) => {
      this.miPosicion = new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude);
      this.actualizarMarcadorMio();
     }).catch((error) => {
       console.log(error);
     });
  }

  escucharGPS(){
    this.escuchando();
    if ( this.activado) {
        setTimeout(() => {
        this.escucharGPS();
        }, 15000);
    }
  }

  escuchando() {
    this.obtenerMiPosicion();
  }

  actualizarMarcadorMio() {
    this.miMarcador.setPosition(this.miPosicion);
    //mandar
    //alert(this.miMarcador.getPosition())
  
  }

  activar() {
    this.escucharGPS();
  }

}
