import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the CuentaPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cuenta',
  templateUrl: 'cuenta.html',
})
export class CuentaPage {
  nombre;
  celular;
  correo;
  contrasena;
  codigo;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.nombre=navParams.get('nombre');
    this.celular=navParams.get('celular');
    this.correo=navParams.get('correo');
    this.contrasena=navParams.get('contrasena');
    this.codigo=navParams.get('codigo');
  }
  

  ionViewDidLoad() {
    console.log('ionViewDidLoad CuentaPage');
  }
}
