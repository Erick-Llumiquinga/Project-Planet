import { HomePage } from './../home/home';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ActionSheetController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  celular;
  nombre;
  correo;
  contrasena;
  codigo=this.hacer();

  miForma: FormGroup;

  splash = true;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formbuilder: FormBuilder
  ) {
    this.miForma = this.crearMiForma();
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    setTimeout(() => this.splash = false, 4000);
  }

  guardarDatos(){
    this.miForma.value;
  }

//validacion
  private crearMiForma(){
    return this.formbuilder.group({
      nombre: ['', Validators.required],
      numero: ['', Validators.required],
      correo: ['', Validators.required],
      contrasenaRetry: this.formbuilder.group({
        contrasena: ['', Validators.required],
        contrasenaConfrimacion: ['',Validators.required]
      })
    });
  }
  

//enviar valores
  ingresar(){
    this.hacer();
    this.navCtrl.setRoot(HomePage, 
      {nombre:this.nombre,
        celular:this.celular,
        correo:this.correo,
        contrasena:this.contrasena,
        codigo:this.codigo
      });
    this.crearMiForma();
  }

  hacer(){
    var letras = new Array('a', 'b', 'c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','z');
    var numeros = new Array('1', '2', '3','4','5','6','7','8','9','0');
    var letraAleatoria = letras[Math.floor(Math.random() * letras.length)];
    var numeroAleatorio = numeros[Math.floor(Math.random() * numeros.length)];
    return(letraAleatoria+numeroAleatorio+letraAleatoria+numeroAleatorio+letraAleatoria+numeroAleatorio);
  } 
}
